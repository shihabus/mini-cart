const HOME = "/";
const CHECKOUT = "/checkout";

export { HOME, CHECKOUT };
