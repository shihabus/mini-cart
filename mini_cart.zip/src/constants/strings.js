const CURRENCY = "₹";
const COMPANY = "Mini Cart";
export { CURRENCY, COMPANY };
