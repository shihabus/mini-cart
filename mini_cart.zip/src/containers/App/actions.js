import actionCreatorUtils from "../../utils/actionCreator";
import * as types from "./actionTypes";

const actionCreator = actionCreatorUtils(types);

export default actionCreator;
