const products = [
  {
    id: 1,
    name: "Rice",
    price: 54.5,
    quantity: 0
  },
  {
    id: 2,
    name: "Honey",
    price: 40.75,
    quantity: 0
  },
  {
    id: 3,
    name: "Atta",
    price: 25,
    quantity: 0
  },
  {
    id: 4,
    name: "Dal",
    price: 32,
    quantity: 0
  },
  {
    id: 5,
    name: "Sugar",
    price: 45,
    quantity: 0
  },
  {
    id: 6,
    name: "Salt",
    price: 10,
    quantity: 0
  },
  {
    id: 7,
    name: "Wheat",
    price: 10,
    quantity: 0
  },
  {
    id: 8,
    name: "Barley",
    price: 10,
    quantity: 0
  },
  {
    id: 9,
    name: "Ghee",
    price: 10,
    quantity: 0
  },
  {
    id: 10,
    name: "Maida",
    price: 10,
    quantity: 0
  },
  {
    id: 11,
    name: "Avocado",
    price: 45,
    quantity: 0
  },
  {
    id: 12,
    name: "Walnut",
    price: 10,
    quantity: 0
  },
  {
    id: 13,
    name: "Groundnut",
    price: 10,
    quantity: 0
  },
  {
    id: 14,
    name: "Mustard",
    price: 10,
    quantity: 0
  },
  {
    id: 15,
    name: "Bajar",
    price: 10,
    quantity: 0
  },
  {
    id: 16,
    name: "Toor Dal",
    price: 10,
    quantity: 0
  }
];

export default products;
